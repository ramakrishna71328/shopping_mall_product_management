package com.tns.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tns.demo.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}