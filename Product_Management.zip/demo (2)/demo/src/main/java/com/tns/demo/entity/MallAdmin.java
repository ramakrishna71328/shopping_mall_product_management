package com.tns.demo.entity;

public class MallAdmin {

private int id;
private String name;
private String password;
private Mall mall;
private String phone;
}